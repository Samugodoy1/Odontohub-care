import { ImageResponse } from "next/og";

export const size = { width: 32, height: 32 };
export const contentType = "image/png";

export default function Icon() {
  return new ImageResponse(
    (
      <div
        style={{
          height: "100%",
          width: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: "#1F6B57",
          color: "#f5f5f7",
          fontSize: 18,
          fontWeight: 600,
        }}
      >
        C
      </div>
    ),
    { ...size },
  );
}
